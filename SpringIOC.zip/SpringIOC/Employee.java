package co.SpringIOC;

public class Employee {
	int eid;
	String name;
	int salary;
	private Address address;
	
	
	
/*	public int getEid() {
		return eid;
	}


	public void setEid(int eid) {
		this.eid = eid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Employee()
	{
		System.out.println("default constructor");
	}
	
	public Employee(int eid, String name, int salary,Address address) {
		super();
		this.eid = eid;
		this.name = name;
		this.salary = salary;
		this.address=address;
	} */



	void show() {
		System.out.println(eid+""+name+""+salary);
		System.out.println(address.toString());
		}
	
	
	
	
	

}
