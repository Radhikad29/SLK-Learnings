package co.SpringIOC;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args)
	{
	//Traditional way
//	Employee e= new Employee();
	//e.setEid(10);
	//e.setName("Radhika");
	//e.setSalary(3000000);
	//e.toString();
	
	//INVERSION OF CONTROL
	// 1. Add jar files for spring core
	//2.Configure java object in an xml file
	//3.Use Spring IOC container ...bean factory or application context
	
	ApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");
	Employee e1= (Employee)context.getBean("e1");
	Employee e2= (Employee)context.getBean("e2");
	
	}

}
