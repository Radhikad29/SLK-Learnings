package co.SpringIOC;

public class Address {

	String city;
	String State;
	
	public Address(String city, String state) {
		super();
		this.city = city;
		State = state;
	}

	@Override
	public String toString() {
		return "Address [city=" + city + ", State=" + State + "]";
	}
	
	
	
	
}
